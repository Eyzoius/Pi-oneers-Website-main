var activepage = document.getElementById("Contact-Us");
activepage.classList.remove('inactivePage');
activepage.classList.add('activePage');