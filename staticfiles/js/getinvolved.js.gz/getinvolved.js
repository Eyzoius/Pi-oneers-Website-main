var activepage = document.getElementById("Get-Involved");
activepage.classList.remove('inactivePage');
activepage.classList.add('activePage');